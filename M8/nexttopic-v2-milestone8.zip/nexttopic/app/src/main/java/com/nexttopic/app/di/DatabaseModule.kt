package com.nexttopic.app.di

import android.content.Context
import androidx.room.Room
import com.nexttopic.app.database.AppDatabase
import com.nexttopic.app.database.dao.ChapterDao
import com.nexttopic.app.database.dao.SubjectDao
import com.nexttopic.app.database.dao.TopicContentDao
import com.nexttopic.app.database.dao.TopicDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, "next_topic.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    fun provideSubjectDao(database: AppDatabase): SubjectDao = database.subjectDao()

    @Provides
    fun provideChapterDao(database: AppDatabase): ChapterDao = database.chapterDao()

    @Provides
    fun provideTopicDao(database: AppDatabase): TopicDao = database.topicDao()

    @Provides
    fun provideTopicContentDao(database: AppDatabase): TopicContentDao = database.topicContentDao()
}
