package com.nexttopic.app.repository

interface TopicContentRepository {
    suspend fun getByTopicExternalId(topicExternalId: String): String?
}
