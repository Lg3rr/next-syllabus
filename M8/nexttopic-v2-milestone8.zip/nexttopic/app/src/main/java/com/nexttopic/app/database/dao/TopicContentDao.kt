package com.nexttopic.app.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.nexttopic.app.database.entity.TopicContentEntity

@Dao
interface TopicContentDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(content: TopicContentEntity)

    @Query("SELECT * FROM topic_content WHERE topicExternalId = :topicExternalId")
    suspend fun getByTopicExternalId(topicExternalId: String): TopicContentEntity?

    @Query("SELECT COUNT(*) FROM topic_content")
    suspend fun getCount(): Int
}
