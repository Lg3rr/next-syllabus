package com.nexttopic.app.ui.topic

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexttopic.app.database.entity.TopicEntity
import com.nexttopic.app.repository.ChapterRepository
import com.nexttopic.app.repository.SubjectRepository
import com.nexttopic.app.repository.TopicContentRepository
import com.nexttopic.app.repository.TopicRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import javax.inject.Inject

sealed interface TopicUiState {
    data object Loading : TopicUiState
    data class Success(
        val topic: TopicEntity,
        val chapterName: String,
        val subjectName: String,
        val overviewSummary: String?
    ) : TopicUiState
    data object Empty : TopicUiState
}

@HiltViewModel
class TopicViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val topicRepository: TopicRepository,
    private val chapterRepository: ChapterRepository,
    private val subjectRepository: SubjectRepository,
    private val topicContentRepository: TopicContentRepository
) : ViewModel() {

    private val topicId: Long = checkNotNull(savedStateHandle["topicId"])
    private val json = Json { ignoreUnknownKeys = true }

    val uiState: StateFlow<TopicUiState> = flow {
        val topic = topicRepository.getById(topicId)
        if (topic == null) {
            emit(TopicUiState.Empty)
            return@flow
        }
        val chapter = chapterRepository.getById(topic.chapterId)
        val subject = chapter?.let { subjectRepository.getById(it.subjectId) }
        val overviewSummary = topicContentRepository.getByTopicExternalId(topic.externalId)
            ?.let { runCatching { extractOverviewSummary(it) }.getOrNull() }
        emit(
            TopicUiState.Success(
                topic = topic,
                chapterName = chapter?.name.orEmpty(),
                subjectName = subject?.name.orEmpty(),
                overviewSummary = overviewSummary
            )
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = TopicUiState.Loading
    )

    private fun extractOverviewSummary(contentJson: String): String? =
        json.parseToJsonElement(contentJson).jsonObject["overview"]
            ?.jsonObject?.get("summary")?.jsonPrimitive?.content
}
