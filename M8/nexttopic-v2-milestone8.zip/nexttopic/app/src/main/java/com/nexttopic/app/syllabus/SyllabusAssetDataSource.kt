package com.nexttopic.app.syllabus

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import java.io.IOException
import javax.inject.Inject

private const val SYLLABUS_ASSET_PATH = "syllabus.json"
private const val TOPIC_CONTENT_ASSET_PATH = "topic_content.json"

class SyllabusAssetDataSource @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val json = Json { ignoreUnknownKeys = false }

    suspend fun loadSyllabus(): Result<SyllabusJson> = withContext(Dispatchers.IO) {
        try {
            val raw = context.assets.open(SYLLABUS_ASSET_PATH).bufferedReader().use { it.readText() }
            Result.success(json.decodeFromString(SyllabusJson.serializer(), raw))
        } catch (e: IOException) {
            Result.failure(e)
        } catch (e: SerializationException) {
            Result.failure(e)
        }
    }

    /**
     * Returns a map of topic externalId -> raw content JSON string.
     * Keys with no content are simply absent; malformed entries are skipped, never crash the app.
     */
    suspend fun loadTopicContentMap(): Result<Map<String, String>> = withContext(Dispatchers.IO) {
        try {
            val raw = context.assets.open(TOPIC_CONTENT_ASSET_PATH).bufferedReader().use { it.readText() }
            val obj = json.parseToJsonElement(raw).jsonObject
            val map = obj.entries.associate { (id, element) -> id to element.toString() }
            Result.success(map)
        } catch (e: IOException) {
            Result.failure(e)
        } catch (e: SerializationException) {
            Result.failure(e)
        }
    }
}
