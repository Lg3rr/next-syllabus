package com.nexttopic.app.repository.impl

import com.nexttopic.app.database.dao.TopicContentDao
import com.nexttopic.app.repository.TopicContentRepository
import javax.inject.Inject

class TopicContentRepositoryImpl @Inject constructor(
    private val topicContentDao: TopicContentDao
) : TopicContentRepository {
    override suspend fun getByTopicExternalId(topicExternalId: String): String? =
        topicContentDao.getByTopicExternalId(topicExternalId)?.contentJson
}
