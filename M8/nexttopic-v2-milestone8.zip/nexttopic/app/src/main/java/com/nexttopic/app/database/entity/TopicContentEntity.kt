package com.nexttopic.app.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "topic_content")
data class TopicContentEntity(
    @PrimaryKey
    val topicExternalId: String,
    val contentJson: String
)
