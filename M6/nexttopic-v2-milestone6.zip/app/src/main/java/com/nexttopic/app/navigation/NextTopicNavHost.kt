package com.nexttopic.app.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.nexttopic.app.ui.chapter.ChapterScreen
import com.nexttopic.app.ui.home.HomeScreen
import com.nexttopic.app.ui.settings.SettingsScreen
import com.nexttopic.app.ui.subject.SubjectScreen
import com.nexttopic.app.ui.topic.TopicScreen

@Composable
fun NextTopicNavHost(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            HomeScreen(
                onSubjectClick = { subjectId ->
                    navController.navigate(Screen.Subject.createRoute(subjectId))
                }
            )
        }
        composable(
            route = Screen.Subject.route,
            arguments = listOf(navArgument("subjectId") { type = NavType.LongType })
        ) {
            SubjectScreen(
                onBackClick = { navController.popBackStack() },
                onChapterClick = { chapterId ->
                    navController.navigate(Screen.Chapter.createRoute(chapterId))
                }
            )
        }
        composable(
            route = Screen.Chapter.route,
            arguments = listOf(navArgument("chapterId") { type = NavType.LongType })
        ) {
            ChapterScreen(
                onBackClick = { navController.popBackStack() },
                onTopicClick = { topicId ->
                    navController.navigate(Screen.Topic.createRoute(topicId))
                }
            )
        }
        composable(
            route = Screen.Topic.route,
            arguments = listOf(navArgument("topicId") { type = NavType.LongType })
        ) {
            TopicScreen()
        }
        composable(Screen.Settings.route) {
            SettingsScreen()
        }
    }
}
