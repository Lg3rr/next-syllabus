package com.nexttopic.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexttopic.app.database.entity.SubjectEntity
import com.nexttopic.app.repository.SubjectRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

sealed interface HomeUiState {
    data object Loading : HomeUiState
    data object Empty : HomeUiState
    data class Success(val subjects: List<SubjectEntity>) : HomeUiState
}

@HiltViewModel
class HomeViewModel @Inject constructor(
    subjectRepository: SubjectRepository
) : ViewModel() {

    val uiState: StateFlow<HomeUiState> = subjectRepository.getAll()
        .map { subjects ->
            if (subjects.isEmpty()) HomeUiState.Empty else HomeUiState.Success(subjects)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = HomeUiState.Loading
        )
}
