package com.nexttopic.app.repository.impl

import com.nexttopic.app.database.dao.SubjectDao
import com.nexttopic.app.database.entity.SubjectEntity
import com.nexttopic.app.repository.SubjectRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class SubjectRepositoryImpl @Inject constructor(
    private val subjectDao: SubjectDao
) : SubjectRepository {
    override suspend fun insert(subject: SubjectEntity): Long = subjectDao.insert(subject)
    override suspend fun update(subject: SubjectEntity) = subjectDao.update(subject)
    override suspend fun delete(subject: SubjectEntity) = subjectDao.delete(subject)
    override suspend fun getById(id: Long): SubjectEntity? = subjectDao.getById(id)
    override fun getAll(): Flow<List<SubjectEntity>> = subjectDao.getAll()
    override suspend fun getCount(): Int = subjectDao.getCount()
}
