package com.nexttopic.app.repository

import com.nexttopic.app.database.entity.ChapterEntity
import kotlinx.coroutines.flow.Flow

interface ChapterRepository {
    suspend fun insert(chapter: ChapterEntity): Long
    suspend fun update(chapter: ChapterEntity)
    suspend fun delete(chapter: ChapterEntity)
    suspend fun getById(id: Long): ChapterEntity?
    fun getBySubjectId(subjectId: Long): Flow<List<ChapterEntity>>
}
