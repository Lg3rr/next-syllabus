package com.nexttopic.app.ui.topic

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

private data class PlaceholderSection(val icon: ImageVector, val label: String)

private val placeholderSections = listOf(
    PlaceholderSection(Icons.Filled.Info, "Overview"),
    PlaceholderSection(Icons.Filled.Edit, "Notes"),
    PlaceholderSection(Icons.Filled.List, "PYQs"),
    PlaceholderSection(Icons.Filled.Refresh, "Revision"),
    PlaceholderSection(Icons.Filled.PlayArrow, "Study Session")
)

@Composable
fun TopicScreen(
    onBackClick: () -> Unit,
    viewModel: TopicViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            val title = when (val state = uiState) {
                is TopicUiState.Success -> state.topic.name
                else -> ""
            }
            TopicTopBar(title = title, onBackClick = onBackClick)
        }
    ) { innerPadding ->
        when (val state = uiState) {
            is TopicUiState.Loading -> {
                Box(
                    modifier = Modifier.fillMaxSize().padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
            is TopicUiState.Empty -> {
                Box(
                    modifier = Modifier.fillMaxSize().padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Topic not found")
                }
            }
            is TopicUiState.Success -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        start = 16.dp,
                        end = 16.dp,
                        top = innerPadding.calculateTopPadding(),
                        bottom = innerPadding.calculateBottomPadding() + 16.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        TopicHeader(
                            topicName = state.topic.name,
                            subjectName = state.subjectName,
                            chapterName = state.chapterName
                        )
                    }
                    items(items = placeholderSections, key = { it.label }) { section ->
                        PlaceholderCard(icon = section.icon, label = section.label)
                    }
                }
            }
        }
    }
}
