package com.nexttopic.app.syllabus

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class SyllabusJson(
    val exam: String,
    @SerialName("class") val classLevel: Int,
    val subjects: List<SubjectJson>
)

@Serializable
data class SubjectJson(
    val id: String,
    val name: String,
    val colorHex: String,
    val orderIndex: Int,
    val chapters: List<ChapterJson>
)

@Serializable
data class ChapterJson(
    val id: String,
    val name: String,
    val orderIndex: Int,
    val topics: List<TopicJson>
)

@Serializable
data class TopicJson(
    val id: String,
    val name: String,
    val orderIndex: Int
)
