package com.nexttopic.app.syllabus

import androidx.room.withTransaction
import com.nexttopic.app.database.AppDatabase
import com.nexttopic.app.repository.ChapterRepository
import com.nexttopic.app.repository.SubjectRepository
import com.nexttopic.app.repository.TopicRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SyllabusSeeder @Inject constructor(
    private val database: AppDatabase,
    private val dataSource: SyllabusAssetDataSource,
    private val subjectRepository: SubjectRepository,
    private val chapterRepository: ChapterRepository,
    private val topicRepository: TopicRepository
) {
    suspend fun seedIfNeeded(): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (subjectRepository.getCount() > 0) return@runCatching

            val syllabus = dataSource.loadSyllabus().getOrThrow()

            database.withTransaction {
                syllabus.subjects.forEach { subjectJson ->
                    val subjectId = subjectRepository.insert(SubjectMapper.toEntity(subjectJson))
                    subjectJson.chapters.forEach { chapterJson ->
                        val chapterId = chapterRepository.insert(
                            ChapterMapper.toEntity(chapterJson, subjectId)
                        )
                        chapterJson.topics.forEach { topicJson ->
                            topicRepository.insert(TopicMapper.toEntity(topicJson, chapterId))
                        }
                    }
                }
            }
        }
    }
}
