package com.nexttopic.app.navigation

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Subject : Screen("subject/{subjectId}") {
        fun createRoute(subjectId: Long) = "subject/$subjectId"
    }
    data object Chapter : Screen("chapter/{chapterId}") {
        fun createRoute(chapterId: Long) = "chapter/$chapterId"
    }
    data object Topic : Screen("topic/{topicId}") {
        fun createRoute(topicId: Long) = "topic/$topicId"
    }
    data object Settings : Screen("settings")
}
