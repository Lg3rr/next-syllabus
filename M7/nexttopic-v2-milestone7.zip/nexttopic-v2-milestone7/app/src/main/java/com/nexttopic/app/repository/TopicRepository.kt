package com.nexttopic.app.repository

import com.nexttopic.app.database.entity.TopicEntity
import kotlinx.coroutines.flow.Flow

interface TopicRepository {
    suspend fun insert(topic: TopicEntity): Long
    suspend fun update(topic: TopicEntity)
    suspend fun delete(topic: TopicEntity)
    suspend fun getById(id: Long): TopicEntity?
    fun getByChapterId(chapterId: Long): Flow<List<TopicEntity>>
}
