package com.nexttopic.app

import android.app.Application
import android.util.Log
import com.nexttopic.app.syllabus.SyllabusSeeder
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp
class NextTopicApp : Application() {

    @Inject
    lateinit var syllabusSeeder: SyllabusSeeder

    private val applicationScope = CoroutineScope(SupervisorJob())

    override fun onCreate() {
        super.onCreate()
        applicationScope.launch {
            syllabusSeeder.seedIfNeeded()
                .onFailure { Log.e("NextTopicApp", "Syllabus seeding failed", it) }
        }
    }
}
