package com.nexttopic.app.ui.subject

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexttopic.app.database.entity.ChapterEntity
import com.nexttopic.app.database.entity.SubjectEntity
import com.nexttopic.app.repository.ChapterRepository
import com.nexttopic.app.repository.SubjectRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

sealed interface SubjectUiState {
    data object Loading : SubjectUiState
    data class Success(val subject: SubjectEntity, val chapters: List<ChapterEntity>) : SubjectUiState
    data class Empty(val subject: SubjectEntity) : SubjectUiState
}

@HiltViewModel
class SubjectViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val subjectRepository: SubjectRepository,
    chapterRepository: ChapterRepository
) : ViewModel() {

    private val subjectId: Long = checkNotNull(savedStateHandle["subjectId"])

    val uiState: StateFlow<SubjectUiState> = chapterRepository.getBySubjectId(subjectId)
        .map { chapters ->
            val subject = subjectRepository.getById(subjectId)
            when {
                subject == null -> SubjectUiState.Loading
                chapters.isEmpty() -> SubjectUiState.Empty(subject)
                else -> SubjectUiState.Success(subject, chapters)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = SubjectUiState.Loading
        )
}
