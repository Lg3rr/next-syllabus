package com.nexttopic.app.ui.chapter

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexttopic.app.database.entity.ChapterEntity
import com.nexttopic.app.database.entity.TopicEntity
import com.nexttopic.app.repository.ChapterRepository
import com.nexttopic.app.repository.TopicRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

sealed interface ChapterUiState {
    data object Loading : ChapterUiState
    data class Success(val chapter: ChapterEntity, val topics: List<TopicEntity>) : ChapterUiState
    data class Empty(val chapter: ChapterEntity) : ChapterUiState
}

@HiltViewModel
class ChapterViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val chapterRepository: ChapterRepository,
    topicRepository: TopicRepository
) : ViewModel() {

    private val chapterId: Long = checkNotNull(savedStateHandle["chapterId"])

    val uiState: StateFlow<ChapterUiState> = topicRepository.getByChapterId(chapterId)
        .map { topics ->
            val chapter = chapterRepository.getById(chapterId)
            when {
                chapter == null -> ChapterUiState.Loading
                topics.isEmpty() -> ChapterUiState.Empty(chapter)
                else -> ChapterUiState.Success(chapter, topics)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = ChapterUiState.Loading
        )
}
