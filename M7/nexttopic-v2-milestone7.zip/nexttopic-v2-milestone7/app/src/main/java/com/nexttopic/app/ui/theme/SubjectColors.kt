package com.nexttopic.app.ui.theme

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

data class SubjectColors(
    val physics: Color = PhysicsBlue,
    val chemistry: Color = ChemistryGreen,
    val botany: Color = BotanyPurple,
    val zoology: Color = ZoologyPink,
    val priorityLow: Color = PriorityLow,
    val priorityMedium: Color = PriorityMedium,
    val priorityHigh: Color = PriorityHigh,
    val prioritySkipped: Color = PrioritySkipped
)

val LocalSubjectColors = staticCompositionLocalOf { SubjectColors() }
