package com.nexttopic.app.ui.theme

import androidx.compose.ui.graphics.Color

// Subject colors (from product plan)
val PhysicsBlue = Color(0xFF3B82F6)
val ChemistryGreen = Color(0xFF22C55E)
val BotanyPurple = Color(0xFFA855F7)
val ZoologyPink = Color(0xFFEC4899)

// Priority chip colors
val PriorityLow = Color(0xFF22C55E)
val PriorityMedium = Color(0xFFF59E0B)
val PriorityHigh = Color(0xFFEF4444)
val PrioritySkipped = Color(0xFF9CA3AF)

// M3 seed-derived tones (light)
val md_theme_light_primary = Color(0xFF3B82F6)
val md_theme_light_onPrimary = Color(0xFFFFFFFF)
val md_theme_light_secondary = Color(0xFF565E71)
val md_theme_light_onSecondary = Color(0xFFFFFFFF)
val md_theme_light_background = Color(0xFFFAFAFA)
val md_theme_light_onBackground = Color(0xFF1A1C1E)
val md_theme_light_surface = Color(0xFFFFFFFF)
val md_theme_light_onSurface = Color(0xFF1A1C1E)
val md_theme_light_error = Color(0xFFBA1A1A)
val md_theme_light_onError = Color(0xFFFFFFFF)

// M3 seed-derived tones (dark)
val md_theme_dark_primary = Color(0xFF9DC5FF)
val md_theme_dark_onPrimary = Color(0xFF00325A)
val md_theme_dark_secondary = Color(0xFFBEC6DC)
val md_theme_dark_onSecondary = Color(0xFF283041)
val md_theme_dark_background = Color(0xFF1A1C1E)
val md_theme_dark_onBackground = Color(0xFFE3E2E6)
val md_theme_dark_surface = Color(0xFF1A1C1E)
val md_theme_dark_onSurface = Color(0xFFE3E2E6)
val md_theme_dark_error = Color(0xFFFFB4AB)
val md_theme_dark_onError = Color(0xFF690005)
