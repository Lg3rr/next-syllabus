package com.nexttopic.app.syllabus

import com.nexttopic.app.database.entity.ChapterEntity
import com.nexttopic.app.database.entity.SubjectEntity
import com.nexttopic.app.database.entity.TopicEntity

object SubjectMapper {
    fun toEntity(json: SubjectJson): SubjectEntity = SubjectEntity(
        name = json.name,
        colorHex = json.colorHex,
        orderIndex = json.orderIndex
    )
}

object ChapterMapper {
    fun toEntity(json: ChapterJson, subjectId: Long): ChapterEntity = ChapterEntity(
        subjectId = subjectId,
        name = json.name,
        orderIndex = json.orderIndex
    )
}

object TopicMapper {
    fun toEntity(json: TopicJson, chapterId: Long): TopicEntity = TopicEntity(
        chapterId = chapterId,
        name = json.name,
        orderIndex = json.orderIndex
    )
}
