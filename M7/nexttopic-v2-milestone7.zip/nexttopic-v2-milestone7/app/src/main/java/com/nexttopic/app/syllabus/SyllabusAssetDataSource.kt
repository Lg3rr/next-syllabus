package com.nexttopic.app.syllabus

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import java.io.IOException
import javax.inject.Inject

private const val SYLLABUS_ASSET_PATH = "syllabus.json"

class SyllabusAssetDataSource @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val json = Json { ignoreUnknownKeys = false }

    suspend fun loadSyllabus(): Result<SyllabusJson> = withContext(Dispatchers.IO) {
        try {
            val raw = context.assets.open(SYLLABUS_ASSET_PATH).bufferedReader().use { it.readText() }
            Result.success(json.decodeFromString(SyllabusJson.serializer(), raw))
        } catch (e: IOException) {
            Result.failure(e)
        } catch (e: SerializationException) {
            Result.failure(e)
        }
    }
}
