package com.nexttopic.app.repository.impl

import com.nexttopic.app.database.dao.ChapterDao
import com.nexttopic.app.database.entity.ChapterEntity
import com.nexttopic.app.repository.ChapterRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class ChapterRepositoryImpl @Inject constructor(
    private val chapterDao: ChapterDao
) : ChapterRepository {
    override suspend fun insert(chapter: ChapterEntity): Long = chapterDao.insert(chapter)
    override suspend fun update(chapter: ChapterEntity) = chapterDao.update(chapter)
    override suspend fun delete(chapter: ChapterEntity) = chapterDao.delete(chapter)
    override suspend fun getById(id: Long): ChapterEntity? = chapterDao.getById(id)
    override fun getBySubjectId(subjectId: Long): Flow<List<ChapterEntity>> = chapterDao.getBySubjectId(subjectId)
}
