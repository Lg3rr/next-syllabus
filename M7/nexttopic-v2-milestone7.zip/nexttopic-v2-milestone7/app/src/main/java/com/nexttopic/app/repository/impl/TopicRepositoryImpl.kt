package com.nexttopic.app.repository.impl

import com.nexttopic.app.database.dao.TopicDao
import com.nexttopic.app.database.entity.TopicEntity
import com.nexttopic.app.repository.TopicRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class TopicRepositoryImpl @Inject constructor(
    private val topicDao: TopicDao
) : TopicRepository {
    override suspend fun insert(topic: TopicEntity): Long = topicDao.insert(topic)
    override suspend fun update(topic: TopicEntity) = topicDao.update(topic)
    override suspend fun delete(topic: TopicEntity) = topicDao.delete(topic)
    override suspend fun getById(id: Long): TopicEntity? = topicDao.getById(id)
    override fun getByChapterId(chapterId: Long): Flow<List<TopicEntity>> = topicDao.getByChapterId(chapterId)
}
