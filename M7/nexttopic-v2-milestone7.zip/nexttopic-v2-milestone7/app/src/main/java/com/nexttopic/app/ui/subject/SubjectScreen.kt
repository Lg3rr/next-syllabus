package com.nexttopic.app.ui.subject

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.nexttopic.app.database.entity.ChapterEntity
import com.nexttopic.app.database.entity.SubjectEntity

private fun parseColorHex(colorHex: String): Color = try {
    Color(android.graphics.Color.parseColor(colorHex))
} catch (e: IllegalArgumentException) {
    Color.Gray
}

@Composable
fun SubjectScreen(
    onBackClick: () -> Unit,
    onChapterClick: (Long) -> Unit,
    viewModel: SubjectViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            val title = when (val state = uiState) {
                is SubjectUiState.Success -> state.subject.name
                is SubjectUiState.Empty -> state.subject.name
                is SubjectUiState.Loading -> ""
            }
            SubjectTopBar(title = title, onBackClick = onBackClick)
        }
    ) { innerPadding ->
        when (val state = uiState) {
            is SubjectUiState.Loading -> {
                Box(
                    modifier = Modifier.fillMaxSize().padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
            is SubjectUiState.Empty -> {
                Box(modifier = Modifier.padding(innerPadding)) {
                    EmptyState()
                }
            }
            is SubjectUiState.Success -> {
                ChapterList(
                    subject = state.subject,
                    chapters = state.chapters,
                    onChapterClick = onChapterClick,
                    contentPadding = innerPadding
                )
            }
        }
    }
}

@Composable
private fun ChapterList(
    subject: SubjectEntity,
    chapters: List<ChapterEntity>,
    onChapterClick: (Long) -> Unit,
    contentPadding: PaddingValues
) {
    val accentColor = parseColorHex(subject.colorHex)
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = contentPadding.calculateTopPadding() + 8.dp,
            bottom = contentPadding.calculateBottomPadding() + 16.dp
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(items = chapters, key = { it.id }) { chapter ->
            ChapterCard(
                chapter = chapter,
                chapterNumber = chapter.orderIndex + 1,
                accentColor = accentColor,
                onClick = { onChapterClick(chapter.id) }
            )
        }
    }
}
