package com.nexttopic.app.di

import com.nexttopic.app.repository.ChapterRepository
import com.nexttopic.app.repository.SubjectRepository
import com.nexttopic.app.repository.TopicRepository
import com.nexttopic.app.repository.impl.ChapterRepositoryImpl
import com.nexttopic.app.repository.impl.SubjectRepositoryImpl
import com.nexttopic.app.repository.impl.TopicRepositoryImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindSubjectRepository(impl: SubjectRepositoryImpl): SubjectRepository

    @Binds
    @Singleton
    abstract fun bindChapterRepository(impl: ChapterRepositoryImpl): ChapterRepository

    @Binds
    @Singleton
    abstract fun bindTopicRepository(impl: TopicRepositoryImpl): TopicRepository
}
