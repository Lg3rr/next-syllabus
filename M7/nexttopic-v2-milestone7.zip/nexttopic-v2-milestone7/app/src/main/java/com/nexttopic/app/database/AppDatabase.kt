package com.nexttopic.app.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.nexttopic.app.database.dao.ChapterDao
import com.nexttopic.app.database.dao.SubjectDao
import com.nexttopic.app.database.dao.TopicDao
import com.nexttopic.app.database.entity.ChapterEntity
import com.nexttopic.app.database.entity.SubjectEntity
import com.nexttopic.app.database.entity.TopicEntity

@Database(
    entities = [SubjectEntity::class, ChapterEntity::class, TopicEntity::class],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun subjectDao(): SubjectDao
    abstract fun chapterDao(): ChapterDao
    abstract fun topicDao(): TopicDao
}
