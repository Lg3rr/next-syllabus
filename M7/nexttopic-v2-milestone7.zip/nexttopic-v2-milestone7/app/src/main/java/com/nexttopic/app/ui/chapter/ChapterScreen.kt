package com.nexttopic.app.ui.chapter

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.nexttopic.app.database.entity.TopicEntity

@Composable
fun ChapterScreen(
    onBackClick: () -> Unit,
    onTopicClick: (Long) -> Unit,
    viewModel: ChapterViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            val title = when (val state = uiState) {
                is ChapterUiState.Success -> state.chapter.name
                is ChapterUiState.Empty -> state.chapter.name
                is ChapterUiState.Loading -> ""
            }
            ChapterTopBar(title = title, onBackClick = onBackClick)
        }
    ) { innerPadding ->
        when (val state = uiState) {
            is ChapterUiState.Loading -> {
                Box(
                    modifier = Modifier.fillMaxSize().padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
            is ChapterUiState.Empty -> {
                Box(modifier = Modifier.padding(innerPadding)) {
                    EmptyState()
                }
            }
            is ChapterUiState.Success -> {
                TopicList(
                    topics = state.topics,
                    onTopicClick = onTopicClick,
                    contentPadding = innerPadding
                )
            }
        }
    }
}

@Composable
private fun TopicList(
    topics: List<TopicEntity>,
    onTopicClick: (Long) -> Unit,
    contentPadding: PaddingValues
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = contentPadding.calculateTopPadding() + 8.dp,
            bottom = contentPadding.calculateBottomPadding() + 16.dp
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(items = topics, key = { it.id }) { topic ->
            TopicRow(
                topic = topic,
                onClick = { onTopicClick(topic.id) }
            )
        }
    }
}
