package com.nexttopic.app.ui.topic

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexttopic.app.database.entity.TopicEntity
import com.nexttopic.app.repository.ChapterRepository
import com.nexttopic.app.repository.SubjectRepository
import com.nexttopic.app.repository.TopicRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

sealed interface TopicUiState {
    data object Loading : TopicUiState
    data class Success(
        val topic: TopicEntity,
        val chapterName: String,
        val subjectName: String
    ) : TopicUiState
    data object Empty : TopicUiState
}

@HiltViewModel
class TopicViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val topicRepository: TopicRepository,
    private val chapterRepository: ChapterRepository,
    private val subjectRepository: SubjectRepository
) : ViewModel() {

    private val topicId: Long = checkNotNull(savedStateHandle["topicId"])

    val uiState: StateFlow<TopicUiState> = flow {
        val topic = topicRepository.getById(topicId)
        if (topic == null) {
            emit(TopicUiState.Empty)
            return@flow
        }
        val chapter = chapterRepository.getById(topic.chapterId)
        val subject = chapter?.let { subjectRepository.getById(it.subjectId) }
        emit(
            TopicUiState.Success(
                topic = topic,
                chapterName = chapter?.name.orEmpty(),
                subjectName = subject?.name.orEmpty()
            )
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = TopicUiState.Loading
    )
}
