package com.nexttopic.app.database

import androidx.room.Database
import androidx.room.RoomDatabase

/**
 * Placeholder database. Entities/DAOs are added in a later milestone.
 */
@Database(entities = [], version = 1, exportSchema = true)
abstract class AppDatabase : RoomDatabase()
