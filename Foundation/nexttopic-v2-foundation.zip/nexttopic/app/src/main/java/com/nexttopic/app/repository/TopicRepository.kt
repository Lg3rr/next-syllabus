package com.nexttopic.app.repository

interface TopicRepository
