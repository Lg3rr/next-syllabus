package com.nexttopic.app.repository

interface SubjectRepository
