package com.nexttopic.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.navigation.compose.rememberNavController
import com.nexttopic.app.navigation.NextTopicNavHost
import com.nexttopic.app.ui.theme.NextTopicTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NextTopicTheme {
                val navController = rememberNavController()
                NextTopicNavHost(navController = navController)
            }
        }
    }
}
