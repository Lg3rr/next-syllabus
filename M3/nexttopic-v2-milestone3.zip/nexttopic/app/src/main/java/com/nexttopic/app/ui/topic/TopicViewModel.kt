package com.nexttopic.app.ui.topic

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class TopicViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle
) : ViewModel() {
    private val topicId: Long = savedStateHandle.get<Long>("topicId") ?: -1L
}
