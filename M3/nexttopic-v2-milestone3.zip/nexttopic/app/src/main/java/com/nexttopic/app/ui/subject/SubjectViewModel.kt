package com.nexttopic.app.ui.subject

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class SubjectViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle
) : ViewModel() {
    private val subjectId: Long = savedStateHandle.get<Long>("subjectId") ?: -1L
}
