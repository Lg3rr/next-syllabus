package com.nexttopic.app.repository

import com.nexttopic.app.database.entity.SubjectEntity
import kotlinx.coroutines.flow.Flow

interface SubjectRepository {
    suspend fun insert(subject: SubjectEntity): Long
    suspend fun update(subject: SubjectEntity)
    suspend fun delete(subject: SubjectEntity)
    suspend fun getById(id: Long): SubjectEntity?
    fun getAll(): Flow<List<SubjectEntity>>
}
